Mdp Private Class(c). All rights reserved.
Contact me for details. --- marcodp183@gmail.com ---
This is Library for learning the arts of the Class and improving knowledge.
Also there are some usefully mathematics function like Expression().linear(self, coeffxx, coeffyy, term), for
resolving simple Linear Systems, or a class for easy MultiThreading.
With the library you will recieve an old-library called 'old_perks', this
library is an old project that contains the Overload Class of some of the
standard built-in types like Integer, String, List, and Floating Point.
With this 2 modules you can easily send an email during your program,
maybe in a Thread, also made with the Task class of the Library.
GNU License imposes that the developer of the Library must be reported at the top of the it.
Do not remove or modify this clauses during the distribution of this.
For any details visit https://grigoprg.webnode.it

Read The LICENSE.txt before sharing the perk_mdplib.
Marco Della Putta, ITALY(c). All rights Reserved.
Do not share the Library without the Releated Files

